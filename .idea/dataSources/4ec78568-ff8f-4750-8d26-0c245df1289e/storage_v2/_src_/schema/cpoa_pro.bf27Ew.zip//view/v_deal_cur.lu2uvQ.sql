create view v_deal_cur as
select `dl`.`DEAL_ID`           AS `DEAL_ID`,
       `dl`.`DEAL_NO`           AS `DEAL_NO`,
       `dl`.`PROJECT_NO`        AS `PROJECT_NO`,
       `dl`.`DEAL_NAME`         AS `DEAL_NAME`,
       `dl`.`DEAL_VALUE`        AS `DEAL_VALUE`,
       `dl`.`CATEGORY_ID`       AS `CATEGORY_ID`,
       `dl`.`DEAL_SIGN_TIME`    AS `DEAL_SIGN_TIME`,
       `dl`.`DEPT_ID`           AS `DEPT_ID`,
       `dl`.`CONTRACT_ID`       AS `CONTRACT_ID`,
       `dl`.`DEAL_INCOME`       AS `DEAL_INCOME`,
       `dl`.`DEAL_FUNDS`        AS `DEAL_FUNDS`,
       `dl`.`DEAL_REPORT_NO`    AS `DEAL_REPORT_NO`,
       `dl`.`DEAL_CONTRACT`     AS `DEAL_CONTRACT`,
       `dl`.`DEAL_DISPUTE`      AS `DEAL_DISPUTE`,
       `dl`.`USER_ID`           AS `USER_ID`,
       `dl`.`DEAL_START`        AS `DEAL_START`,
       `dl`.`DEAL_END`          AS `DEAL_END`,
       `dl`.`DEAL_SELECTION`    AS `DEAL_SELECTION`,
       `dl`.`DEAL_SETTLEMENT`   AS `DEAL_SETTLEMENT`,
       `dl`.`SETTLE_DATE`       AS `SETTLE_DATE`,
       `dl`.`DEAL_NOTES`        AS `DEAL_NOTES`,
       `dl`.`CREATE_AT`         AS `CREATE_AT`,
       `dl`.`DEAL_CURRENCY`     AS `DEAL_CURRENCY`,
       `dl`.`SUBTYPE_ID`        AS `SUBTYPE_ID`,
       `dl`.`DEAL_STATUS`       AS `DEAL_STATUS`,
       `dl`.`DEAL_TYPE`         AS `DEAL_TYPE`,
       `dl`.`PAYMENT_TYPE`      AS `PAYMENT_TYPE`,
       `dl`.`PAYMENT_REQ`       AS `PAYMENT_REQ`,
       `dl`.`DEAL_VALUE_AFTER`  AS `DEAL_VALUE_AFTER`,
       `dl`.`DEAL_VALUE_BEFORE` AS `DEAL_VALUE_BEFORE`,
       `dl`.`HAVE_TAX`          AS `HAVE_TAX`,
       `dl`.`TAX_RATE`          AS `TAX_RATE`,
       `dl`.`CHANGE_DESC`       AS `CHANGE_DESC`,
       `dl`.`PLACED_TIME`       AS `PLACED_TIME`
from `cpoa_pro`.`t_biz_deal` `dl`
where ((`dl`.`DEAL_INCOME` = '收入') and (`dl`.`DEAL_SIGN_TIME` >= (`fn_curyear`() - interval 1 year)) and
       (`dl`.`DEAL_SIGN_TIME` < `fn_curyear`()) and (exists(select 1
                                                            from `cpoa_pro`.`t_biz_deal_ex` `ex`
                                                            where ((`ex`.`DEAL_INCOME` = '收入') and
                                                                   (`ex`.`DEAL_SIGN_TIME` >= (`fn_curyear`() - interval 1 year)) and
                                                                   (`dl`.`DEAL_SIGN_TIME` < `fn_curyear`()) and
                                                                   (`ex`.`DEAL_ID` = `dl`.`DEAL_ID`))) is false) and
       (`dl`.`DEAL_STATUS` in ('progressAuditing', 'changeAuditing', 'changeBack', 'placing', 'placed')))
union
select `idl`.`DEAL_ID`           AS `DEAL_ID`,
       `idl`.`DEAL_NO`           AS `DEAL_NO`,
       `idl`.`PROJECT_NO`        AS `PROJECT_NO`,
       `idl`.`DEAL_NAME`         AS `DEAL_NAME`,
       `idl`.`DEAL_VALUE`        AS `DEAL_VALUE`,
       `idl`.`CATEGORY_ID`       AS `CATEGORY_ID`,
       `idl`.`DEAL_SIGN_TIME`    AS `DEAL_SIGN_TIME`,
       `idl`.`DEPT_ID`           AS `DEPT_ID`,
       `idl`.`CONTRACT_ID`       AS `CONTRACT_ID`,
       `idl`.`DEAL_INCOME`       AS `DEAL_INCOME`,
       `idl`.`DEAL_FUNDS`        AS `DEAL_FUNDS`,
       `idl`.`DEAL_REPORT_NO`    AS `DEAL_REPORT_NO`,
       `idl`.`DEAL_CONTRACT`     AS `DEAL_CONTRACT`,
       `idl`.`DEAL_DISPUTE`      AS `DEAL_DISPUTE`,
       `idl`.`USER_ID`           AS `USER_ID`,
       `idl`.`DEAL_START`        AS `DEAL_START`,
       `idl`.`DEAL_END`          AS `DEAL_END`,
       `idl`.`DEAL_SELECTION`    AS `DEAL_SELECTION`,
       `idl`.`DEAL_SETTLEMENT`   AS `DEAL_SETTLEMENT`,
       `idl`.`SETTLE_DATE`       AS `SETTLE_DATE`,
       `idl`.`DEAL_NOTES`        AS `DEAL_NOTES`,
       `idl`.`CREATE_AT`         AS `CREATE_AT`,
       `idl`.`DEAL_CURRENCY`     AS `DEAL_CURRENCY`,
       `idl`.`SUBTYPE_ID`        AS `SUBTYPE_ID`,
       `idl`.`DEAL_STATUS`       AS `DEAL_STATUS`,
       `idl`.`DEAL_TYPE`         AS `DEAL_TYPE`,
       `idl`.`PAYMENT_TYPE`      AS `PAYMENT_TYPE`,
       `idl`.`PAYMENT_REQ`       AS `PAYMENT_REQ`,
       `idl`.`DEAL_VALUE_AFTER`  AS `DEAL_VALUE_AFTER`,
       `idl`.`DEAL_VALUE_BEFORE` AS `DEAL_VALUE_BEFORE`,
       `idl`.`HAVE_TAX`          AS `HAVE_TAX`,
       `idl`.`TAX_RATE`          AS `TAX_RATE`,
       `idl`.`CHANGE_DESC`       AS `CHANGE_DESC`,
       `idl`.`PLACED_TIME`       AS `PLACED_TIME`
from `cpoa_pro`.`t_biz_deal_in` `idl`
where ((`idl`.`DEAL_INCOME` = '收入') and (`idl`.`DEAL_SIGN_TIME` >= (`fn_curyear`() - interval 1 year)) and
       (`idl`.`DEAL_SIGN_TIME` < `fn_curyear`()))
union
select `dl`.`DEAL_ID`           AS `DEAL_ID`,
       `dl`.`DEAL_NO`           AS `DEAL_NO`,
       `dl`.`PROJECT_NO`        AS `PROJECT_NO`,
       `dl`.`DEAL_NAME`         AS `DEAL_NAME`,
       `dl`.`DEAL_VALUE`        AS `DEAL_VALUE`,
       `dl`.`CATEGORY_ID`       AS `CATEGORY_ID`,
       `dl`.`DEAL_SIGN_TIME`    AS `DEAL_SIGN_TIME`,
       `dl`.`DEPT_ID`           AS `DEPT_ID`,
       `dl`.`CONTRACT_ID`       AS `CONTRACT_ID`,
       `dl`.`DEAL_INCOME`       AS `DEAL_INCOME`,
       `dl`.`DEAL_FUNDS`        AS `DEAL_FUNDS`,
       `dl`.`DEAL_REPORT_NO`    AS `DEAL_REPORT_NO`,
       `dl`.`DEAL_CONTRACT`     AS `DEAL_CONTRACT`,
       `dl`.`DEAL_DISPUTE`      AS `DEAL_DISPUTE`,
       `dl`.`USER_ID`           AS `USER_ID`,
       `dl`.`DEAL_START`        AS `DEAL_START`,
       `dl`.`DEAL_END`          AS `DEAL_END`,
       `dl`.`DEAL_SELECTION`    AS `DEAL_SELECTION`,
       `dl`.`DEAL_SETTLEMENT`   AS `DEAL_SETTLEMENT`,
       `dl`.`SETTLE_DATE`       AS `SETTLE_DATE`,
       `dl`.`DEAL_NOTES`        AS `DEAL_NOTES`,
       `dl`.`CREATE_AT`         AS `CREATE_AT`,
       `dl`.`DEAL_CURRENCY`     AS `DEAL_CURRENCY`,
       `dl`.`SUBTYPE_ID`        AS `SUBTYPE_ID`,
       `dl`.`DEAL_STATUS`       AS `DEAL_STATUS`,
       `dl`.`DEAL_TYPE`         AS `DEAL_TYPE`,
       `dl`.`PAYMENT_TYPE`      AS `PAYMENT_TYPE`,
       `dl`.`PAYMENT_REQ`       AS `PAYMENT_REQ`,
       `dl`.`DEAL_VALUE_AFTER`  AS `DEAL_VALUE_AFTER`,
       `dl`.`DEAL_VALUE_BEFORE` AS `DEAL_VALUE_BEFORE`,
       `dl`.`HAVE_TAX`          AS `HAVE_TAX`,
       `dl`.`TAX_RATE`          AS `TAX_RATE`,
       `dl`.`CHANGE_DESC`       AS `CHANGE_DESC`,
       `dl`.`PLACED_TIME`       AS `PLACED_TIME`
from `cpoa_pro`.`t_biz_deal_hd` `dl`
where ((`dl`.`DEAL_INCOME` = '收入') and (`dl`.`DEAL_SIGN_TIME` >= (`fn_curyear`() - interval 1 year)) and
       (`dl`.`DEAL_SIGN_TIME` < `fn_curyear`()) and (exists(select 1
                                                            from `cpoa_pro`.`t_biz_deal_ex` `ex`
                                                            where ((`ex`.`DEAL_INCOME` = '收入') and
                                                                   (`ex`.`DEAL_SIGN_TIME` >= (`fn_curyear`() - interval 1 year)) and
                                                                   (`ex`.`DEAL_ID` = `dl`.`DEAL_ID`))) is false) and
       (`dl`.`DEAL_STATUS` in ('progressAuditing', 'changeAuditing', 'changeBack', 'placing', 'placed')));

