create view v_deal_api_001 as
select `dl`.`DEAL_NAME`                          AS `DEAL_NAME`,
       `dp`.`ALIAS_NAME1`                        AS `DEPT_NAME`,
       `dl`.`DEAL_SIGN_TIME`                     AS `DEAL_SIGN_TIME`,
       `cpoa_pro`.`t_biz_contractor`.`CONT_NAME` AS `CONT_NAME`,
       `dl`.`DEAL_END`                           AS `DEAL_END`,
       `dl`.`DEAL_VALUE`                         AS `DEAL_VALUE`,
       `dl`.`DEAL_SETTLEMENT`                    AS `DEAL_SETTLEMENT`,
       `dl`.`DEAL_TYPE`                          AS `DEAL_TYPE`,
       `dl`.`DEAL_NO`                            AS `DEAL_NO`
from ((`cpoa_pro`.`t_biz_deal` `dl` left join `cpoa_pro`.`t_sys_dept` `dp` on ((`dl`.`DEPT_ID` = `dp`.`DEPT_ID`)))
         left join `cpoa_pro`.`t_biz_contractor` on ((`dl`.`CONTRACT_ID` = `cpoa_pro`.`t_biz_contractor`.`CONT_ID`)));

