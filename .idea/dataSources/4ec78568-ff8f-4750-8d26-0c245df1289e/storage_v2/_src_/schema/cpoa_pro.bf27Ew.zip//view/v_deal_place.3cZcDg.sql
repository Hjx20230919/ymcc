create view v_deal_place as
select `mm`.`deal_id` AS `deal_id`, `mm`.`placedtime` AS `placedtime`, `mdl`.`DEAL_END` AS `deal_end`
from ((select `kk`.`DEAL_ID` AS `deal_id`, max(`kk`.`placedtime`) AS `placedtime`
       from (select `stm`.`DEAL_ID` AS `DEAL_ID`, max(`sp`.`STEP_END_AT`) AS `placedtime`
             from (`cpoa_pro`.`t_biz_settlement` `stm`
                      join `cpoa_pro`.`t_biz_check_step` `sp`)
             where ((`stm`.`SETTLE_ID` = `sp`.`CHECK_OBJ_ID`) and
                    (isnull(`stm`.`NOTES`) or (not ((`stm`.`NOTES` like '%初始数据导入%')))))
             group by `stm`.`DEAL_ID`
             union
             select `stm`.`DEAL_ID` AS `DEAL_ID`, max(`stm`.`CREATE_TIME`) AS `placedtime`
             from `cpoa_pro`.`t_biz_settlement` `stm`
             where (`stm`.`NOTES` like '%初始数据导入%')
             group by `stm`.`DEAL_ID`) `kk`
       group by `kk`.`DEAL_ID`) `mm`
         join `cpoa_pro`.`t_biz_deal` `mdl`)
where ((`mm`.`deal_id` = `mdl`.`DEAL_ID`) and (`mdl`.`DEAL_STATUS` = 'placed'));

