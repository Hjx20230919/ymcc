create view tmpv_deal_2020 as
select `ddl`.`DEAL_ID`                              AS `deal_ID`,
       `cnt`.`CONT_ID`                              AS `CONT_ID`,
       `ddl`.`USER_ID`                              AS `user_id`,
       `ddl`.`DEPT_ID`                              AS `dept_id`,
       `ddl`.`DEAL_TYPE`                            AS `合同类型`,
       `ddl`.`DEAL_NO`                              AS `合同编号`,
       `ddl`.`DEAL_NAME`                            AS `合同名称`,
       `ddl`.`DEAL_VALUE`                           AS `合同金额`,
       `ddl`.`DEAL_SIGN_TIME`                       AS `签订时间`,
       `ddl`.`DEAL_STATUS`                          AS `合同状态`,
       (select `stt`.`SETTLE_STATUS`
        from `cpoa_pro`.`t_biz_settlement` `stt`
        where (`stt`.`DEAL_ID` = `ddl`.`DEAL_ID`)
        order by `stt`.`CREATE_TIME` desc
        limit 1)                                    AS `结算状态`,
       `ddl`.`DEAL_REPORT_NO`                       AS `报审号`,
       `ddl`.`DEAL_CONTRACT`                        AS `我方签约单位`,
       `dpt`.`DEPT_NAME`                            AS `经办部门`,
       `cnt`.`CONT_NAME`                            AS `相对人`,
       (select concat_ws('|', convert(`fn_conttype`(`cnt`.`MARKET_TYPE`) using utf8mb4),
                         convert(`fn_conttype`(`cnt2`.`COMPANY_TYPE`) using utf8mb4),
                         convert(`fn_conttype`(`cnt2`.`WORK_ZONE`) using utf8mb4),
                         convert(`fn_conttype`(`cnt2`.`CONTRACT_TYPE`) using utf8mb4))
        from `cpoa_pro`.`t_biz_contractor` `cnt2`
        where (`cnt2`.`CONT_ID` = `cnt`.`CONT_ID`)) AS `交易类型`
from ((`cpoa_pro`.`t_biz_deal` `ddl` left join `cpoa_pro`.`t_biz_contractor` `cnt` on ((`cnt`.`CONT_ID` = `ddl`.`CONTRACT_ID`)))
         left join `cpoa_pro`.`t_sys_dept` `dpt` on ((`dpt`.`DEPT_ID` = `ddl`.`DEPT_ID`)))
where ((`ddl`.`DEAL_TYPE` in ('TH', 'NZ', 'XX', 'XS')) and (`ddl`.`DEAL_INCOME` = '收入') and
       (`ddl`.`DEAL_STATUS` not in ('draft', 'back', 'buildAuditing')) and
       (date_format(`ddl`.`DEAL_SIGN_TIME`, '%Y-%m-%d') >= '2020-01-01'))
order by `ddl`.`DEAL_TYPE`, `ddl`.`DEAL_SIGN_TIME`;

