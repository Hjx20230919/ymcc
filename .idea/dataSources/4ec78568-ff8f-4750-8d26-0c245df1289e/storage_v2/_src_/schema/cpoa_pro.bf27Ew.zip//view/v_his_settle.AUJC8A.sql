create view v_his_settle as
select `dl`.`DEAL_ID`                                                             AS `DEAL_ID`,
       `dl`.`DEAL_NO`                                                             AS `DEAL_NO`,
       `dl`.`DEAL_NAME`                                                           AS `DEAL_NAME`,
       (select ifnull(sum(`stl`.`SETTLE_AMOUNT`), 0)
        from `cpoa_pro`.`t_biz_settlement` `stl`
        where ((`stl`.`DEAL_ID` = `dl`.`DEAL_ID`) and
               (`stl`.`CREATE_TIME` < str_to_date('2020-01-01', '%Y-%m-%d %H')))) AS `hissettle`
from `cpoa_pro`.`t_biz_deal` `dl`
where (`dl`.`DEAL_SIGN_TIME` < str_to_date('2020-01-01', '%Y-%m-%d %H'));

