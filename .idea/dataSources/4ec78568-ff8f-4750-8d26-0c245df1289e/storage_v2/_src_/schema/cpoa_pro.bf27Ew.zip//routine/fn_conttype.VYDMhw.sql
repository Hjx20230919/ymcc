create
    definer = root@localhost function fn_conttype(l_type varchar(50)) returns varchar(50)
begin
  DECLARE  l_ret VARCHAR(50);
   SELECT
		CASE
			WHEN l_type = 'DOMESTIC' then '国内'
			WHEN l_type = 'OVERSEAS' then '国外'
			WHEN l_type = 'CCDE_INNER' then '川庆内部'
			WHEN l_type = 'CNPC_INNER' then '集团内部'
			WHEN l_type = 'CNPC_OUTER' then '集团外部'
			WHEN l_type = 'SC_CQ_ZONE' then '川渝地区'
			WHEN l_type = 'TLM_ZONE' then '塔里木地区'
			WHEN l_type = 'XJ_ZONE' then '新疆地区'
			WHEN l_type = 'CQ_ZONE' then '长庆地区'
			WHEN l_type = 'HW_ZONE' then '海外地区'
			WHEN l_type = 'HS_ZONE' then '海上地区'
			WHEN l_type = 'BF_ZONE' then '北方地区'
			WHEN l_type = 'RELATED' then '关联交易'
			WHEN l_type = 'UNRELATED' then '非关联交易'
			WHEN l_type = 'NZ' then '内部责任书'
			WHEN l_type = 'INSTRUCTION' then '指令项目'
			WHEN l_type = 'TRANSFER' then '划拨项目'
			WHEN l_type = 'TH' then '三万以下'
			WHEN l_type = 'COMMON' THEN '常规'
			WHEN l_type = 'SHALE_GAS' then '页燃气'
			WHEN l_type = 'WHOLE_PACK' then '整包合同'
			WHEN l_type = 'MAN_DAY'THEN '人天'
			WHEN l_type = 'WORKLOAD' THEN '工作量'
			-- 承包商专业类别
				WHEN l_type = 'engineeringTechnology' THEN '工程技术'
        WHEN l_type = 'engineeringTechnologyDelete' THEN '工程技术(已销项)'
        WHEN l_type = 'environmentalProtection' THEN '安全环保'
        WHEN l_type = 'environmentalProtectionDelete' THEN '安全环保(已销项)'
        WHEN l_type = 'networkInformation' THEN '网络信息'
        WHEN l_type = 'networkInformationDelete' THEN '网络信息(已销项)'
        WHEN l_type = 'equipmentMaintenance' THEN '设备维修'
        WHEN l_type = 'equipmentMaintenanceDelete' THEN '设备维修(已销项)'
        WHEN l_type = 'logisticsTransportation' THEN '物流运输'
        WHEN l_type = 'logisticsTransportationDelete' THEN '物流运输(已销项)'
        WHEN l_type = 'technicalService' THEN '技术服务'
        WHEN l_type = 'technicalServiceDelete' THEN '技术服务(已销项)'
        WHEN l_type = 'operationService' THEN '操作服务'
        WHEN l_type = 'operationServiceDelete' THEN '操作服务(已销项)'
        WHEN l_type = 'engineeringConstruction' THEN '工程建设'
        WHEN l_type = 'engineeringConstructionDelete' THEN '工程建设(已销项)'
        WHEN l_type = 'other' THEN '其他'
        WHEN l_type = 'otherDelete' THEN '其他(已销项)'
		ELSE 
			l_type
		END
	INTO l_ret;
    RETURN l_ret;
end;

