create view tmp_settle_err as
select `cpoa_pro`.`t_biz_check_step`.`CHECK_OBJ_ID` AS `CHECK_OBJ_ID`
from `cpoa_pro`.`t_biz_check_step`
where (`cpoa_pro`.`t_biz_check_step`.`CHECK_OBJ_ID` in (select `cpoa_pro`.`t_biz_settlement`.`SETTLE_ID`
                                                        from `cpoa_pro`.`t_biz_settlement`
                                                        where `cpoa_pro`.`t_biz_settlement`.`DEAL_ID` in
                                                              (select `cpoa_pro`.`t_biz_deal`.`DEAL_ID`
                                                               from `cpoa_pro`.`t_biz_deal`
                                                               where (`cpoa_pro`.`t_biz_deal`.`DEAL_TYPE` = 'XS'))) and
       (`cpoa_pro`.`t_biz_check_step`.`CHECK_OBJ_TYPE` = 'settle'))
group by `cpoa_pro`.`t_biz_check_step`.`CHECK_OBJ_ID`
having (count(0) = 1);

