create view v_check_obj as
select `cs`.`CHECK_OBJ_ID` AS `CHECK_OBJ_ID`, max(`cs`.`STEP_END_AT`) AS `CHECKtime`
from `cpoa_pro`.`t_biz_check_step` `cs`
group by `cs`.`CHECK_OBJ_ID`;

