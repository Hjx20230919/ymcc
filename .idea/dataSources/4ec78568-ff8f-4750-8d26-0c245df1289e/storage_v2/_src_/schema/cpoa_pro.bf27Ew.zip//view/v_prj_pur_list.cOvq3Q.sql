create view v_prj_pur_list as
select `prt`.`PROJ_ID`                AS `PROJ_ID`,
       `prt`.`RESULT_ID`              AS `RESULT_ID`,
       `cnt`.`CONT_ID`                AS `CONT_ID`,
       `cnt`.`CONT_NAME`              AS `CONT_NAME`,
       sum(`prl`.`LIMIT_TOTAL_PRICE`) AS `sum(prl.limit_total_price)`
from ((`cpoa_pro`.`t_proj_purc_result` `prt` join `cpoa_pro`.`t_proj_result_list` `prl`)
         join `cpoa_pro`.`t_cont_contractor` `cnt`)
where ((`prt`.`RESULT_ID` = `prl`.`RESULT_ID`) and (`prl`.`CONT_ID` = `cnt`.`CONT_ID`))
group by `prt`.`PROJ_ID`, `prt`.`RESULT_ID`, `cnt`.`CONT_ID`, `cnt`.`CONT_NAME`;

