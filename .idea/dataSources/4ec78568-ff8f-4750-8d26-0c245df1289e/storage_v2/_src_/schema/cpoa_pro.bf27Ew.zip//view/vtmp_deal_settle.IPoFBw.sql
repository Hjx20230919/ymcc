create view vtmp_deal_settle as
select `dl`.`DEAL_ID`                                                                                          AS `DEAL_ID`,
       `dl`.`DEAL_NO`                                                                                          AS `DEAL_NO`,
       `dl`.`DEAL_NAME`                                                                                        AS `DEAL_NAME`,
       `dl`.`DEAL_VALUE`                                                                                       AS `DEAL_VALUE`,
       `dl`.`CATEGORY_ID`                                                                                      AS `CATEGORY_ID`,
       `dl`.`DEAL_SIGN_TIME`                                                                                   AS `DEAL_SIGN_TIME`,
       `dl`.`DEPT_ID`                                                                                          AS `DEPT_ID`,
       `dl`.`CONTRACT_ID`                                                                                      AS `CONTRACT_ID`,
       `dl`.`DEAL_INCOME`                                                                                      AS `DEAL_INCOME`,
       `dl`.`DEAL_FUNDS`                                                                                       AS `DEAL_FUNDS`,
       `dl`.`DEAL_REPORT_NO`                                                                                   AS `DEAL_REPORT_NO`,
       `dl`.`DEAL_CONTRACT`                                                                                    AS `DEAL_CONTRACT`,
       `dl`.`DEAL_DISPUTE`                                                                                     AS `DEAL_DISPUTE`,
       `dl`.`USER_ID`                                                                                          AS `USER_ID`,
       `dl`.`DEAL_START`                                                                                       AS `DEAL_START`,
       `dl`.`DEAL_END`                                                                                         AS `DEAL_END`,
       `dl`.`DEAL_SELECTION`                                                                                   AS `DEAL_SELECTION`,
       `dl`.`DEAL_SETTLEMENT`                                                                                  AS `DEAL_SETTLEMENT`,
       `dl`.`SETTLE_DATE`                                                                                      AS `SETTLE_DATE`,
       `dl`.`DEAL_NOTES`                                                                                       AS `DEAL_NOTES`,
       `dl`.`CREATE_AT`                                                                                        AS `CREATE_AT`,
       `dl`.`DEAL_CURRENCY`                                                                                    AS `DEAL_CURRENCY`,
       `dl`.`SUBTYPE_ID`                                                                                       AS `SUBTYPE_ID`,
       `dl`.`DEAL_STATUS`                                                                                      AS `DEAL_STATUS`,
       `dl`.`DEAL_TYPE`                                                                                        AS `DEAL_TYPE`,
       `dl`.`PAYMENT_TYPE`                                                                                     AS `PAYMENT_TYPE`,
       `dl`.`PAYMENT_REQ`                                                                                      AS `PAYMENT_REQ`,
       `dl`.`DEAL_VALUE_AFTER`                                                                                 AS `DEAL_VALUE_AFTER`,
       `dl`.`DEAL_VALUE_BEFORE`                                                                                AS `DEAL_VALUE_BEFORE`,
       `dl`.`HAVE_TAX`                                                                                         AS `HAVE_TAX`,
       `dl`.`TAX_RATE`                                                                                         AS `TAX_RATE`,
       year(`dl`.`DEAL_SIGN_TIME`)                                                                             AS `签定年`,
       (select ifnull(sum(`stl`.`SETTLE_AMOUNT`), 0)
        from `cpoa_pro`.`t_biz_settlement` `stl`
        where ((`stl`.`DEAL_ID` = `dl`.`DEAL_ID`) and (`stl`.`SETTLE_STATUS` = 'down') and
               (year(`stl`.`DOWN_TIME`) = year(`dl`.`DEAL_SIGN_TIME`))))                                       AS `签定年结算`,
       (select ifnull(sum(`stl`.`SETTLE_AMOUNT`), 0)
        from `cpoa_pro`.`t_biz_settlement` `stl`
        where ((`stl`.`DEAL_ID` = `dl`.`DEAL_ID`) and (`stl`.`SETTLE_STATUS` = 'down') and
               (`stl`.`DOWN_TIME` < str_to_date('2021-01-01', '%Y-%m-%d'))))                                   AS `往年结算`,
       (select ifnull(sum(`stl`.`SETTLE_AMOUNT`), 0)
        from `cpoa_pro`.`t_biz_settlement` `stl`
        where ((`stl`.`DEAL_ID` = `dl`.`DEAL_ID`) and (`stl`.`SETTLE_STATUS` = 'down') and
               (`stl`.`CREATE_TIME` >= str_to_date('2021-01-01', '%Y-%m-%d'))))                                AS `本年结算`,
       (case when (`dl`.`DEAL_SIGN_TIME` < str_to_date('2021-01-01', '%Y-%m-%d')) then '跨年合同' else '本年合同' end) AS `合同历史`
from `cpoa_pro`.`t_biz_deal` `dl`
where ((isnull(`dl`.`PLACED_TIME`) or (`dl`.`PLACED_TIME` >= str_to_date('2021-01-01', '%Y-%m-%d'))) and
       (`dl`.`DEAL_STATUS` not in ('back', 'buildAuditing', 'draft')));

