create view vtmp_accatt as
select `dl`.`ID` AS `ID`
from `cpoa_pro`.`t_cont_acce_worker_state_attach` `dl`
where (`dl`.`ATTACH_ID` in (select `cpoa_pro`.`t_cont_acce_worker_state_attach`.`ATTACH_ID`
                            from `cpoa_pro`.`t_cont_acce_worker_state_attach`
                            group by `cpoa_pro`.`t_cont_acce_worker_state_attach`.`ATTACH_ID`
                            having (count(0) > 1)) and
       (`dl`.`ID` in (select max(`cpoa_pro`.`t_cont_acce_worker_state_attach`.`ID`)
                      from `cpoa_pro`.`t_cont_acce_worker_state_attach`
                      group by `cpoa_pro`.`t_cont_acce_worker_state_attach`.`ATTACH_ID`
                      having (count(0) > 1)) is false));

