create
    definer = root@localhost function fn_lastyear() returns date
BEGIN
	#Routine body goes here...

	RETURN DATE_FORMAT((DATE_SUB((DATE_SUB(NOW(),INTERVAL dayofyear(now())-1 DAY)),INTERVAL 1 YEAR)),'%Y-%m-%d');
END;

