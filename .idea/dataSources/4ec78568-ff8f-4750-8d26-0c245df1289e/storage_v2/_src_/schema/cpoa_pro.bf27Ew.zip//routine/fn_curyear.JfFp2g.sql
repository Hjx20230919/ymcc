create
    definer = root@localhost function fn_curyear() returns date
BEGIN
	#Routine body goes here...

	RETURN DATE_FORMAT(DATE_SUB(CURDATE(),INTERVAL dayofyear(now())-1 DAY),'%Y-%m-%d');
END;

