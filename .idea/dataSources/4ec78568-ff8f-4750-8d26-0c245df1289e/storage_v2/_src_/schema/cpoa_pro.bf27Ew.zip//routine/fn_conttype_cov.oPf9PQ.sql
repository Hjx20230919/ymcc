create
    definer = root@localhost function fn_conttype_cov(l_type varchar(50)) returns varchar(50)
BEGIN
  DECLARE  l_ret VARCHAR(50);
   SELECT
		CASE
			WHEN l_type = '国内' then 'DOMESTIC'
			WHEN l_type = '国外' then 'OVERSEAS'
			WHEN l_type = '川庆内部' then 'CCDE_INNER'
			WHEN l_type = '集团内部' then 'CNPC_INNER'
			WHEN l_type = '集团外部' then 'CNPC_OUTER'
			WHEN l_type = '川渝地区' then 'SC_CQ_ZONE'
			WHEN l_type = '塔里木地区' then 'TLM_ZONE'
			WHEN l_type = '新疆地区' then 'XJ_ZONE'
			WHEN l_type = '长庆地区' then 'CQ_ZONE'
			WHEN l_type = '海外地区' then 'HW_ZONE'
			WHEN l_type = '上海地区' then 'HS_ZONE'
			WHEN l_type = '海上地区' then 'HS_ZONE'
			WHEN l_type = '天津地区' then 'HS_ZONE'
			WHEN l_type = '北方地区' then 'BF_ZONE'
			WHEN l_type = '关联交易' then 'RELATED'
			WHEN l_type = '非关联交易' then 'UNRELATED'
			WHEN l_type = '内部责任书' then 'NZ'
			WHEN l_type = '指令项目' then 'INSTRUCTION'
			WHEN l_type = '指令性任务' then 'INSTRUCTION'
			WHEN l_type = '划拨项目' then 'TRANSFER'
			WHEN l_type = '三万以下' then 'TH'
			WHEN l_type = '常规' THEN 'COMMON'
			WHEN l_type = '页燃气' then 'SHALE_GAS'
			WHEN l_type = '整包合同' then 'WHOLE_PACK'
			WHEN l_type = '人天'THEN 'MAN_DAY'
			WHEN l_type = '工作量' THEN 'WORKLOAD'
		ELSE 
			null
		END
	INTO l_ret;
    RETURN l_ret;
END;

